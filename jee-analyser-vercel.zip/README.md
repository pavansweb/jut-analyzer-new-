# JEE Marks Analyser API

Flask API for the supplied JEE marks analyser frontend.

## Environment variables

Set these in Vercel:

```text
GITHUB_TOKEN=...
GITHUB_REPO=OWNER/REPO
GITHUB_BRANCH=main
GITHUB_DATA_PATH=data/jee_data.json
API_WRITE_KEY=...
```

The GitHub token stays server-side. Give the token repository **Contents: Read and write** permission.

## API

### GET /api/health

Checks configuration.

### GET /api/students

Returns student IDs and names.

### GET /api/scores?student=<id>&subject=<physics|chemistry|maths|consolidated>

Returns the score format expected by the current frontend. Consolidated entries also contain `rank` when available.

### POST /api/students

Requires `X-API-Key`.

```json
{"id":"pavan","name":"Pavan"}
```

### POST /api/scores

Requires `X-API-Key`.

```json
{
  "student":"pavan",
  "subject":"physics",
  "test_no":1,
  "date":"2026-08-01",
  "marks":72
}
```

For total + rank:

```json
{
  "student":"pavan",
  "subject":"consolidated",
  "test_no":1,
  "date":"2026-08-01",
  "marks":218,
  "rank":1234
}
```

When Physics, Chemistry and Maths are all entered for a test, `total` is calculated automatically.

## Vercel

Vercel supports Flask as a Python serverless function with `api/index.py` containing the top-level `app`.

The frontend and API can live in the same Vercel project/domain, so the frontend can keep using relative URLs such as `/api/students`.
